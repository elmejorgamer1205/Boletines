package Examen;

public class Nave {

    private Cartucho cartucho;

    public void cargarDeposito(int Indice, Cartucho c) {

    }
}
