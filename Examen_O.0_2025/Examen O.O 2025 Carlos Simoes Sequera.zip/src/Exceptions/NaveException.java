package Exceptions;

public class NaveException extends Exception {
    public NaveException(String message) {
        super(message);
    }
}
